# OneForAll-ws-api
API Websocket for OneForAll https://github.com/shmilylty/OneForAll
